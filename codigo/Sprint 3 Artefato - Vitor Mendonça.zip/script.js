var lol_jogos = [
    {
        "data": "13/04/2024 15:00",
        "campeonato": "Cblol",
        "times": {
            "time_a": {
                "nome": "Pain",
                "img": "https://upload.wikimedia.org/wikipedia/pt/5/5d/PainGaming.png"
            },
            "time_b": {
                "nome": "Loud",
                "img": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/LOUD_logo.svg/1200px-LOUD_logo.svg.png"
            }
        },
        "resultado": {
            "pontuacao_time_a": 1,
            "pontuacao_time_b": 3
        }
    },
    {
        "data": "15/04/2024 16:00",
        "campeonato": "Cblol",
        "times": {
            "time_a": {
                "nome": "Furia",
                "img": "https://upload.wikimedia.org/wikipedia/pt/f/f9/Furia_Esports_logo.png"
            },
            "time_b": {
                "nome": "Intz",
                "img": "https://intz.com.br/wp-content/uploads/2019/10/INTZ_Logo_Principal_2022.png"
            }
        },
        "resultado": {
            "pontuacao_time_a": 1,
            "pontuacao_time_b": 3
        }
    },
    {
        "data": "16/04/2024 16:00",
        "campeonato": "Cblol",
        "times": {
            "time_a": {
                "nome": "Fluxo",
                "img": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEBJwOrlVmBIGTTziG_KZFvZfRqp7UJnfEO8Z_ji8DmA&s"
            },
            "time_b": {
                "nome": "Kabum",
                "img": "https://pm1.aminoapps.com/6743/de686a056e10c16124d5dff523a914ff0789c866v2_00.jpg"
            }
        },
        "resultado": {
            "pontuacao_time_a": 3,
            "pontuacao_time_b": 1
        }
    },
    {
        "data": "05/05/2024 16:00",
        "campeonato": "Cblol",
        "times": {
            "time_a": {
                "nome": "Liberty",
                "img": "https://static1.squarespace.com/static/61afb10ae1f7cf52bfb3dd13/t/61b2690c6e2d5c6aa3f405e5/1716504893187/"
            },
            "time_b": {
                "nome": "RED Canids",
                "img": "https://w7.pngwing.com/pngs/543/393/png-transparent-red-canids-tom-clancy-s-rainbow-six-siege-league-of-legends-hearthstone-esl-pro-league-league-of-legends.png"
            }
        },
        "resultado": {
            "pontuacao_time_a": 3,
            "pontuacao_time_b": 1
        }
    }
];
var detalharJogos = [
    {
        "local": "Morumbi",
        "horario": "13/04/2024 15:00"
    },
    {
        "local": "Pacaembu",
        "horario": "15/04/2024 16:00"
    },
    {
        "local": "Mineirinho",
        "horario": "16/04/2024 16:00"
    },
    {
        "local": "Vila belmiro",
        "horario": "05/05/2024 16:00"
    },
]

function atualizarJogos() {
    // Jogo 1
    document.querySelector("#campeonato_1").innerHTML = lol_jogos[0].campeonato;
    document.querySelector("#data_1").innerHTML = lol_jogos[0].data;
    document.querySelector("#imagem_time_1").src = lol_jogos[0].times.time_a.img;
    document.querySelector("#imagem_time_2").src = lol_jogos[0].times.time_b.img;
    document.querySelector("#placar_1").innerHTML = lol_jogos[0].resultado.pontuacao_time_a;
    document.querySelector("#placar_2").innerHTML = lol_jogos[0].resultado.pontuacao_time_b;

    // Jogo 2
    document.querySelector("#campeonato_2").innerHTML = lol_jogos[1].campeonato;
    document.querySelector("#data_2").innerHTML = lol_jogos[1].data;
    document.querySelector("#imagem_time_3").src = lol_jogos[1].times.time_a.img;
    document.querySelector("#imagem_time_4").src = lol_jogos[1].times.time_b.img;
    document.querySelector("#placar_3").innerHTML = lol_jogos[1].resultado.pontuacao_time_a;
    document.querySelector("#placar_4").innerHTML = lol_jogos[1].resultado.pontuacao_time_b;

    // Jogo 3
    document.querySelector("#campeonato_3").innerHTML = lol_jogos[2].campeonato;
    document.querySelector("#data_3").innerHTML = lol_jogos[2].data;
    document.querySelector("#imagem_time_5").src = lol_jogos[2].times.time_a.img;
    document.querySelector("#imagem_time_6").src = lol_jogos[2].times.time_b.img;
    document.querySelector("#placar_5").innerHTML = lol_jogos[2].resultado.pontuacao_time_a;
    document.querySelector("#placar_6").innerHTML = lol_jogos[2].resultado.pontuacao_time_b;

    // Jogo 4
    document.querySelector("#campeonato_4").innerHTML = lol_jogos[3].campeonato;
    document.querySelector("#data_4").innerHTML = lol_jogos[3].data;
    document.querySelector("#imagem_time_7").src = lol_jogos[3].times.time_a.img;
    document.querySelector("#imagem_time_8").src = lol_jogos[3].times.time_b.img;
    document.querySelector("#placar_7").innerHTML = lol_jogos[3].resultado.pontuacao_time_a;
    document.querySelector("#placar_8").innerHTML = lol_jogos[3].resultado.pontuacao_time_b;

    var images = document.querySelectorAll('img');
    images.forEach(function(img) {
        img.addEventListener('click', function() {
            var url = img.getAttribute('data-url');
            window.location.href = url;
        });
    });
    var tela = document.querySelector("#tela")
    tela.classList.add("displayNone")
    
}

function detalheJogos_1(){
        var tela = document.querySelector("#tela")
        tela.classList.remove("displayNone")
        document.querySelector("#local").innerHTML = detalharJogos[0].local
        document.querySelector("#horario").innerHTML = detalharJogos[0].horario
}

function fecharTela_1(){
    var tela = document.querySelector("#tela")
    tela.classList.add("displayNone")
}

function detalheJogos_2(){
    var tela = document.querySelector("#tela")
    tela.classList.remove("displayNone")
    document.querySelector("#local").innerHTML = detalharJogos[1].local
    document.querySelector("#horario").innerHTML = detalharJogos[1].horario
}

function fecharTela_2(){
    var tela = document.querySelector("#tela")
    tela.classList.add("displayNone")
}

function detalheJogos_3(){
    var tela = document.querySelector("#tela")
    tela.classList.remove("displayNone")
    document.querySelector("#local").innerHTML = detalharJogos[2].local
    document.querySelector("#horario").innerHTML = detalharJogos[2].horario
}

function fecharTela_3(){
    var tela = document.querySelector("#tela")
    tela.classList.add("displayNone")
}

function detalheJogos_4(){
    var tela = document.querySelector("#tela")
    tela.classList.remove("displayNone")
    document.querySelector("#local").innerHTML = detalharJogos[3].local
    document.querySelector("#horario").innerHTML = detalharJogos[3].horario
}

function fecharTela_4(){
    var tela = document.querySelector("#tela")
    tela.classList.add("displayNone")
}