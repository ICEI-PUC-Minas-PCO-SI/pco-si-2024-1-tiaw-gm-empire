var jogadores = [
    {
        "time": "Pain",
        "jogadores": [
        {   
            "nome": "Wizer",
            "lane": "Top",
            "img": "https://pbs.twimg.com/profile_images/1661396162446802953/6vfQ6go7_400x400.jpg"
        },
        {
            "nome": "CarioK",
            "lane": "Jungler",
            "img": "https://s2-ge.glbimg.com/4aZvPubnvUTmo1uzKTVYhUjIQxo=/0x0:1067x656/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2021/s/V/H8B28IT46Aegpr1E6Qig/cariok-pain-lol.jpg",
        },
        {
            "nome": "DyNquedo",
            "lane": "Mid",
            "img": "https://cdn.ome.lt/8B93QVyvHdUUcvHM5rFHs999yNE=/1200x630/smart/extras/conteudos/imagem_2023-12-15_122852895.png",
        },
        {
            "nome": "Titan",
            "lane": "Bot",
            "img":  "https://s2-ge.glbimg.com/y1TN5pr7109qzO8x5C-_le1A-Kc=/0x0:1349x705/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2023/w/M/qjOYkCStyLSW1fDgGolw/captura-de-tela-2023-12-19-181940.png"
        },
        {
            "nome": "Kuri",
            "lane": "Suport",
            "img": "https://pbs.twimg.com/profile_images/1746762596940754944/8gB275Tw_400x400.jpg",
        }

    ]
    }
    
]
var jogos = [
    {
        "data": "13/04/2024 15:00",
        "campeonato": "Cblol",
        "times": {
            "time_a": {
                "nome": "Pain",
                "img": "https://upload.wikimedia.org/wikipedia/pt/5/5d/PainGaming.png"
            },
            "time_b": {
                "nome": "Loud",
                "img": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/LOUD_logo.svg/1200px-LOUD_logo.svg.png"
            }
        },
        "resultado": {
            "pontuacao_time_a": 1,
            "pontuacao_time_b": 3
        }
    },
    {
        "data": "15/04/2024 16:00",
        "campeonato": "Cblol",
        "times": {
            "time_a": {
                "nome": "Pain",
                "img": "https://upload.wikimedia.org/wikipedia/pt/5/5d/PainGaming.png"
            },
            "time_b": {
                "nome": "Intz",
                "img": "https://intz.com.br/wp-content/uploads/2019/10/INTZ_Logo_Principal_2022.png"
            }
        },
        "resultado": {
            "pontuacao_time_a": 1,
            "pontuacao_time_b": 3
        }
    },
]
function atualizarDados(){
    // elenco
    document.querySelector("#nome_time").innerHTML = jogadores[0].time
    for(let i = 0; i < 5; i++){
    document.querySelector(`#jogador_${i + 1}`).innerHTML = jogadores[0].jogadores[i].nome
    document.querySelector(`#jogador_${i + 1}_foto`).src = jogadores[0].jogadores[i].img
    document.querySelector(`#lane_${i + 1}`).innerHTML = jogadores[0].jogadores[i].lane
    }

    // jogos
    document.querySelector("#campeonato_1").innerHTML = jogos[0].campeonato;
    document.querySelector("#data_1").innerHTML = jogos[0].data;
    document.querySelector("#imagem_time_1").src = jogos[0].times.time_a.img;
    document.querySelector("#imagem_time_2").src = jogos[0].times.time_b.img;
    document.querySelector("#placar_1").innerHTML = jogos[0].resultado.pontuacao_time_a;
    document.querySelector("#placar_2").innerHTML = jogos[0].resultado.pontuacao_time_b;

    document.querySelector("#campeonato_2").innerHTML = jogos[1].campeonato;
    document.querySelector("#data_2").innerHTML = jogos[1].data;
    document.querySelector("#imagem_time_3").src = jogos[1].times.time_a.img;
    document.querySelector("#imagem_time_4").src = jogos[1].times.time_b.img;
    document.querySelector("#placar_3").innerHTML = jogos[1].resultado.pontuacao_time_a;
    document.querySelector("#placar_4").innerHTML = jogos[1].resultado.pontuacao_time_b;
    var images = document.querySelectorAll('img');
    images.forEach(function(img) {
        img.addEventListener('click', function() {
            var url = img.getAttribute('data-url');
            window.location.href = url;
        });
    });
}