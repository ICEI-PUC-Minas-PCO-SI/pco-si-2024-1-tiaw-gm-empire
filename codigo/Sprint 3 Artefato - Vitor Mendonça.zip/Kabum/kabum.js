var jogadores = [
    {
        "time": "Kabum",
        "jogadores": [
        {   
            "nome": "Lonely",
            "lane": "Top",
            "img": "https://cdn.ome.lt/wIq5KJHo-Wf_3gZRusr7j-utIrs=/770x0/smart/uploads/conteudo/fotos/lonely.webp"
        },
        {
            "nome": "Malrang",
            "lane": "Jungler",
            "img": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZQ25J39Cqs_s-4MH5xFI2ctJ6prm6mYL9LA&s",
        },
        {
            "nome": "Hauz",
            "lane": "Mid",
            "img": "https://s2-ge.glbimg.com/DV-capCd8xSb3Z0pMaL-VFex1lo=/1200x/smart/filters:cover():strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2022/v/B/DmfLfOTCSzivlpAMGZow/hauz-kabum-playoffs-cblol-2022-2o-split.jpg",
        },
        {
            "nome": "Netuno",
            "lane": "Bot",
            "img":  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRkbhS2YOYK5IUS2nIyjiuKHZDwHvoykSH8uw&s"
        },
        {
            "nome": "Ceos",
            "lane": "Suport",
            "img": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQP5xNkNuZ1gSJ5ydZkkTBI2r6_IxrOxTuEEw&s",
        }

    ]
    }
    
]
var jogos = [
    {
        "data": "13/04/2024 15:00",
        "campeonato": "Cblol",
        "times": {
            "time_a": {
                "nome": "Kabum",
                "img": "https://pm1.aminoapps.com/6743/de686a056e10c16124d5dff523a914ff0789c866v2_00.jpg"
            },
            "time_b": {
                "nome": "Pain",
                "img": "https://upload.wikimedia.org/wikipedia/pt/5/5d/PainGaming.png"
            }
        },
        "resultado": {
            "pontuacao_time_a": 1,
            "pontuacao_time_b": 3
        }
    },
    {
        "data": "15/04/2024 16:00",
        "campeonato": "Cblol",
        "times": {
            "time_a": {
                "nome": "Kabum",
                "img": "https://pm1.aminoapps.com/6743/de686a056e10c16124d5dff523a914ff0789c866v2_00.jpg"
            },
            "time_b": {
                "nome": "Intz",
                "img": "https://intz.com.br/wp-content/uploads/2019/10/INTZ_Logo_Principal_2022.png"
            }
        },
        "resultado": {
            "pontuacao_time_a": 1,
            "pontuacao_time_b": 3
        }
    },
]
function atualizarDados(){
    // elenco
    document.querySelector("#nome_time").innerHTML = jogadores[0].time
    for(let i = 0; i < 5; i++){
    document.querySelector(`#jogador_${i + 1}`).innerHTML = jogadores[0].jogadores[i].nome
    document.querySelector(`#jogador_${i + 1}_foto`).src = jogadores[0].jogadores[i].img
    document.querySelector(`#lane_${i + 1}`).innerHTML = jogadores[0].jogadores[i].lane
    }

    // jogos
    document.querySelector("#campeonato_1").innerHTML = jogos[0].campeonato;
    document.querySelector("#data_1").innerHTML = jogos[0].data;
    document.querySelector("#imagem_time_1").src = jogos[0].times.time_a.img;
    document.querySelector("#imagem_time_2").src = jogos[0].times.time_b.img;
    document.querySelector("#placar_1").innerHTML = jogos[0].resultado.pontuacao_time_a;
    document.querySelector("#placar_2").innerHTML = jogos[0].resultado.pontuacao_time_b;

    document.querySelector("#campeonato_2").innerHTML = jogos[1].campeonato;
    document.querySelector("#data_2").innerHTML = jogos[1].data;
    document.querySelector("#imagem_time_3").src = jogos[1].times.time_a.img;
    document.querySelector("#imagem_time_4").src = jogos[1].times.time_b.img;
    document.querySelector("#placar_3").innerHTML = jogos[1].resultado.pontuacao_time_a;
    document.querySelector("#placar_4").innerHTML = jogos[1].resultado.pontuacao_time_b;
    var images = document.querySelectorAll('img');
    images.forEach(function(img) {
        img.addEventListener('click', function() {
            var url = img.getAttribute('data-url');
            window.location.href = url;
        });
    });
}