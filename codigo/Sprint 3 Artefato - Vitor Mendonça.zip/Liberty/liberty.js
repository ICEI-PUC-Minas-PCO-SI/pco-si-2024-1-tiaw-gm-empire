var jogadores = [
    {
        "time": "Liberty",
        "jogadores": [
        {   
            "nome": "Makes",
            "lane": "Top",
            "img": "https://www.pichauarena.com.br/wp-content/uploads/2024/01/53476705249_53554c212e_c.jpg"
        },
        {
            "nome": "Drakehero",
            "lane": "Jungler",
            "img": "https://pbs.twimg.com/profile_images/1732058345224261632/8q8owlvG_400x400.jpg",
        },
        {
            "nome": "Piloto",
            "lane": "Mid",
            "img": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTzoaw77_LRiKrBeV5G5evOyAQlFjcl9trFWg&s",
        },
        {
            "nome": "micaO",
            "lane": "Bot",
            "img":  "https://s2-ge.glbimg.com/Z4fvHgHRTvF1iJfVqjX3n6RClOI=/0x0:1920x1280/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2022/0/Z/3yPKbkRDScDUtERv2Jlw/cblol-2022-micao-intz.jpg"
        },
        {
            "nome": "Cavalo",
            "lane": "Suport",
            "img": "https://s2-ge.glbimg.com/IqjnqUwUxeoe7rNCQ_GFfx8ePis=/0x0:1263x820/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2022/X/H/cWnskQRWm89Jn9MsdM4Q/cavalo-liberty-academy-divulgacao-liberty.jpg",
        }

    ]
    }
    
]
var jogos = [
    {
        "data": "13/04/2024 15:00",
        "campeonato": "Cblol",
        "times": {
            "time_a": {
                "nome": "Liberty",
                "img": "https://static1.squarespace.com/static/61afb10ae1f7cf52bfb3dd13/t/61b2690c6e2d5c6aa3f405e5/1716504893187/"
            },
            "time_b": {
                "nome": "Pain",
                "img": "https://upload.wikimedia.org/wikipedia/pt/5/5d/PainGaming.png"
            }
        },
        "resultado": {
            "pontuacao_time_a": 1,
            "pontuacao_time_b": 3
        }
    },
    {
        "data": "15/04/2024 16:00",
        "campeonato": "Cblol",
        "times": {
            "time_a": {
                "nome": "Liberty",
                "img": "https://static1.squarespace.com/static/61afb10ae1f7cf52bfb3dd13/t/61b2690c6e2d5c6aa3f405e5/1716504893187/"
            },
            "time_b": {
                "nome": "Intz",
                "img": "https://intz.com.br/wp-content/uploads/2019/10/INTZ_Logo_Principal_2022.png"
            }
        },
        "resultado": {
            "pontuacao_time_a": 1,
            "pontuacao_time_b": 3
        }
    },
]
function atualizarDados(){
    // elenco
    document.querySelector("#nome_time").innerHTML = jogadores[0].time
    for(let i = 0; i < 5; i++){
    document.querySelector(`#jogador_${i + 1}`).innerHTML = jogadores[0].jogadores[i].nome
    document.querySelector(`#jogador_${i + 1}_foto`).src = jogadores[0].jogadores[i].img
    document.querySelector(`#lane_${i + 1}`).innerHTML = jogadores[0].jogadores[i].lane
    }

    // jogos
    document.querySelector("#campeonato_1").innerHTML = jogos[0].campeonato;
    document.querySelector("#data_1").innerHTML = jogos[0].data;
    document.querySelector("#imagem_time_1").src = jogos[0].times.time_a.img;
    document.querySelector("#imagem_time_2").src = jogos[0].times.time_b.img;
    document.querySelector("#placar_1").innerHTML = jogos[0].resultado.pontuacao_time_a;
    document.querySelector("#placar_2").innerHTML = jogos[0].resultado.pontuacao_time_b;

    document.querySelector("#campeonato_2").innerHTML = jogos[1].campeonato;
    document.querySelector("#data_2").innerHTML = jogos[1].data;
    document.querySelector("#imagem_time_3").src = jogos[1].times.time_a.img;
    document.querySelector("#imagem_time_4").src = jogos[1].times.time_b.img;
    document.querySelector("#placar_3").innerHTML = jogos[1].resultado.pontuacao_time_a;
    document.querySelector("#placar_4").innerHTML = jogos[1].resultado.pontuacao_time_b;
    var images = document.querySelectorAll('img');
    images.forEach(function(img) {
        img.addEventListener('click', function() {
            var url = img.getAttribute('data-url');
            window.location.href = url;
        });
    });
}