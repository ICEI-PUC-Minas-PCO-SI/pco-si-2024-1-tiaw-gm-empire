var ultimosJogos = [
    {
        "data": "13/04/2024 13:00",
        "jogo": "Lol",
        "campeonato": "Cblol",
        "times": {
            "time_a": {
                "nome": "Pain",
                "img": "Foto pain.png"
            },
            "time_b": "Loud",
        },
        "resultado": {
            "pontuacao_time_a": 1,
            "pontuacao_time_b": 3,
        }
    },
    {
        "data": "13/04/2024 13:00",
        "jogo": "Valorant",
        "campeonato": "VCT",
        "times": {
            "time_a": "Furia",
            "time_b": "Kru",
        },
        "resultado": {
            "pontuacao_time_a": 1,
            "pontuacao_time_b": 2,
        }
    }
]
function atualizar(){
    // Pega a data do primeiro jogo e a partir do DOM coloca no html
    var data1_json = ultimosJogos[0].data
    var data1 = document.querySelector("#data1")
    data1.innerHTML = (`${data1_json}`)
    // Pega os placares do primeiro jogo e a partir do DOM coloca no html
    var placar1_json = ultimosJogos[0].resultado.pontuacao_time_a
    var placar1 = document.querySelector("#placar1")
    placar1.innerHTML = (`${placar1_json}`)
    var placar2_json = ultimosJogos[0].resultado.pontuacao_time_b
    var placar2 = document.querySelector("#placar2")
    placar2.innerHTML = (`${placar2_json}`)
    //Pega o cameponato no json e joga no site
    var campeonato1_json = ultimosJogos[0].campeonato
    var campeonato1 = document.querySelector("#campeonato1")
    campeonato1.innerHTML = (`${campeonato1_json}`)
    var data2_json = ultimosJogos[1].data
    var data2 = document.querySelector("#data2")
    data2.innerHTML = (`${data2_json}`)
    // Pega os placares do primeiro jogo e a partir do DOM coloca no html
    var placar3_json = ultimosJogos[1].resultado.pontuacao_time_a
    var placar3 = document.querySelector("#placar3")
    placar3.innerHTML = (`${placar3_json}`)
    var placar4_json = ultimosJogos[1].resultado.pontuacao_time_b
    var placar4 = document.querySelector("#placar4")
    placar4.innerHTML = (`${placar4_json}`)
    //Pega o cameponato no json e joga no site
    var campeonato2_json = ultimosJogos[1].campeonato
    var campeonato2 = document.querySelector("#campeonato2")
    campeonato2.innerHTML = (`${campeonato2_json}`)
}